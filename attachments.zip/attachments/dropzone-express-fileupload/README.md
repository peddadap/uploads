dropzone-express-fileupload
===========================

Fileupload with Dropzone &amp; Express.js

### Install
* Download/Clone this repo
* Run `npm install`
* Run `gulp` and navigate to `http://localhost:3000`

Tutorial : [Uploading files with Dropzone.js and Express.js](http://thejackalofjavascript.com/uploading-files-with-dropzone-js-and-express-js)
